Please place your profile image in this folder with the filename 'profile.jpg'

The image should be:
1. Named exactly "profile.jpg"
2. Preferably in a 1:1 aspect ratio (square)
3. At least 300x300 pixels for good quality

Once you've added your image to this folder, rebuild the app to see your profile image in the portfolio. 